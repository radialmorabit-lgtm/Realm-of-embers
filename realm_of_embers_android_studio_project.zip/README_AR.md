# مشروع أندرويد — مملكة الجمر

هذا مشروع Android Studio يغلّف اللعبة الحالية داخل تطبيق Android باستخدام WebView، مع شاشة أفقية ووضع ملء الشاشة.

## بناء APK على الكمبيوتر
1. ثبّت Android Studio على Windows أو macOS أو Linux.
2. افتح Android Studio واختر **Open** ثم مجلد المشروع `RealmOfEmbers`.
3. وافق على تثبيت/تنزيل Android SDK Platform 35 وأدوات البناء التي يطلبها Android Studio.
4. انتظر انتهاء Gradle Sync.
5. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. بعد النجاح سيظهر رابط تحديد مكان الملف. غالبًا يكون في:
   `app/build/outputs/apk/debug/app-debug.apk`
7. انقل `app-debug.apk` إلى هاتفك وافتحه لتثبيته. قد يطلب Android السماح بالتثبيت من هذا المصدر.

## ملاحظات
- هذا المشروع ليس ملف APK مبنيًا مسبقًا؛ يجب بناؤه بواسطة Android Studio مع Android SDK.
- لا يحتاج التطبيق إلى اتصال إنترنت أثناء اللعب.
- اللعبة نفسها نسخة أولية 2D، ولم يتم اختبار هذا الغلاف على أجهزة فعلية في هذه البيئة.
